// admin.js — simple admin dashboard client
const API_URL =
  (window.APP_CONFIG && window.APP_CONFIG.API_URL) ||
  "http://localhost:5000/api"; // backend URL
// If you have backend auth route (/api/auth/login) set to true to use real login
const USE_BACKEND_AUTH = !!(
  window.APP_CONFIG && window.APP_CONFIG.USE_BACKEND_AUTH
);

let jwtToken = null;

// --------- UI elements
const loginSection = document.getElementById("login-section");
const adminDashboardContent = document.getElementById(
  "admin-dashboard-content"
);
const loginMsg = document.getElementById("loginMsg");
const loginBtn = document.getElementById("loginBtn");

// Event listeners
if (loginBtn) {
  loginBtn.addEventListener("click", handleLogin);
}

// --------- Navigation and Modals
function showSection(sectionId, targetButton) {
  // Hide all sections
  document.querySelectorAll(".section").forEach((section) => {
    section.classList.add("hidden");
  });

  // Show selected section
  document.getElementById(sectionId).classList.remove("hidden");

  // Update navigation buttons
  document.querySelectorAll(".nav-btn").forEach((btn) => {
    btn.classList.remove("bg-gold", "text-charcoal", "shadow-lg");
  });
  if (targetButton) {
    targetButton.classList.add("bg-gold", "text-charcoal", "shadow-lg");
  }
}

// Attach event listeners for navigation buttons after DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
  document
    .getElementById("nav-dashboard")
    ?.addEventListener("click", (event) => {
      showSection("dashboard", event.currentTarget);
    });
  document.getElementById("nav-rooms")?.addEventListener("click", (event) => {
    showSection("rooms", event.currentTarget);
  });
  document.getElementById("nav-guests")?.addEventListener("click", (event) => {
    showSection("guests", event.currentTarget);
    loadGuests(); // Load guests when navigating to guest management
  });
  document
    .getElementById("nav-housekeeping")
    ?.addEventListener("click", (event) => {
      showSection("housekeeping", event.currentTarget);
      loadHousekeepingTasks(); // Load housekeeping tasks when navigating to housekeeping
    });
  document
    .getElementById("nav-payments")
    ?.addEventListener("click", (event) => {
      showSection("payments", event.currentTarget);
      loadPayments(); // Load payments when navigating to payments
    });
  document.getElementById("nav-food")?.addEventListener("click", (event) => {
    showSection("food", event.currentTarget);
    loadMenuItems(); // Load menu items when navigating to food & beverage
    loadRoomServiceOrders(); // Load room service orders when navigating to food & beverage
  });
  document.getElementById("nav-staff")?.addEventListener("click", (event) => {
    showSection("staff", event.currentTarget);
    loadStaff(); // Load staff when navigating to staff management
  });
  document.getElementById("nav-reports")?.addEventListener("click", (event) => {
    showSection("reports", event.currentTarget);
  });
  document
    .getElementById("nav-communication")
    ?.addEventListener("click", (event) => {
      showSection("communication", event.currentTarget);
    });
  document
    .getElementById("nav-security")
    ?.addEventListener("click", (event) => {
      showSection("security", event.currentTarget);
    });

  // Event listener for "View All Rooms" button on the dashboard
  document
    .getElementById("view-all-rooms-btn")
    ?.addEventListener("click", (event) => {
      showSection("rooms", document.getElementById("nav-rooms"));
    });
});

function openModal(modalId) {
  document.getElementById(modalId).classList.remove("hidden");
}

function closeModal(modalId) {
  document.getElementById(modalId).classList.add("hidden");
}

// Close modals when clicking outside
window.onclick = function (event) {
  if (event.target.classList.contains("modal")) {
    event.target.classList.add("hidden");
  }
};

// --------- LOGIN
async function handleLogin() {
  const usernameInput = document.getElementById("username");
  const passwordInput = document.getElementById("password");
  const username = usernameInput ? usernameInput.value.trim() : "";
  const password = passwordInput ? passwordInput.value.trim() : "";

  if (!username || !password) {
    if (loginMsg) loginMsg.textContent = "Enter both username and password.";
    return;
  }

  if (USE_BACKEND_AUTH) {
    // Attempt backend login
    try {
      const res = await fetch(`${API_URL}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (loginMsg) loginMsg.textContent = data.message || "Login failed";
        return;
      }
      jwtToken = data.token;
      showDashboard();
    } catch (err) {
      if (loginMsg) loginMsg.textContent = "Login error: " + err.message;
    }
  } else {
    // Simple local test login — username: admin, password: 1234
    if (username === "admin" && password === "1234") {
      showDashboard();
    } else {
      if (loginMsg)
        loginMsg.textContent = "Wrong username or password (try admin / 1234).";
    }
  }
}

function showDashboard() {
  if (loginSection) loginSection.classList.add("hidden");
  if (adminDashboardContent) adminDashboardContent.classList.remove("hidden");
  if (loginMsg) loginMsg.textContent = "";

  // Initialize dashboard content after showing it
  // Ensure the dashboard section is shown and rooms/bookings are loaded
  showSection("dashboard"); // This will also set the active nav button
  loadRooms();
  loadBookings();
  loadGuests(); // Load guests when dashboard is shown

  // Attach event listener for addRoomForm
  const addRoomForm = document.getElementById("addRoomForm");
  if (addRoomForm) {
    addRoomForm.addEventListener("submit", addRoom);
  }
}

// --------- ROOMS
async function loadRooms() {
  try {
    const res = await fetch(`${API_URL}/rooms`, fetchOptions("GET"));
    const rooms = await res.json();
    const container = document.querySelector("#rooms .grid"); // Target the grid in the rooms section
    if (!Array.isArray(rooms)) {
      container.innerHTML = '<p class="muted">No room data returned.</p>';
      return;
    }
    container.innerHTML = rooms
      .map(
        (r) => `
      <div class="bg-white p-6 rounded-lg shadow-md border-l-4 ${
        r.status === "occupied"
          ? "border-green-500"
          : r.status === "available"
          ? "border-blue-500"
          : "border-red-500"
      }">
          <div class="flex justify-between items-start mb-4">
              <h3 class="text-xl font-semibold">Room ${escapeHtml(r.id)}</h3>
              <span class="px-2 py-1 rounded text-sm" style="background:${
                r.status === "occupied"
                  ? "#22c55e"
                  : r.status === "available"
                  ? "#3b82f6"
                  : "#ef4444"
              };color:#fff">${
          r.status.charAt(0).toUpperCase() + r.status.slice(1)
        }</span>
          </div>
          <p class="text-gray-600 mb-2">${escapeHtml(r.type)}</p>
          <p class="text-brown font-semibold mb-4">₦${(
            r.rate || 0
          ).toLocaleString()}/night</p>
          <div class="space-y-2">
              <button onclick="viewRoomDetails(${
                r.id
              })" class="w-full bg-gold hover:bg-gold-dark text-brown py-2 rounded">View Details</button>
              <button onclick="changeRoomStatus(${
                r.id
              })" class="w-full bg-brown hover:bg-brown-dark text-white py-2 rounded">Change Status</button>
              <button onclick="deleteRoom(${
                r.id
              })" class="w-full bg-red-500 hover:bg-red-600 text-white py-2 rounded">Delete</button>
          </div>
      </div>
    `
      )
      .join("");
  } catch (err) {
    document.querySelector(
      "#rooms .grid"
    ).innerHTML = `<p class="muted">Error loading rooms: ${err.message}</p>`;
  }
}

async function addRoom(event) {
  event.preventDefault();
  const form = event.target;
  const roomNumber = form
    .querySelector('input[name="roomNumber"]')
    .value.trim();
  const roomType = form.querySelector('select[name="roomType"]').value;
  const roomRate = Number(form.querySelector('input[name="roomRate"]').value);

  if (!roomNumber || !roomType || !roomRate) {
    if (window.UI && UI.toast)
      UI.toast("Please fill in all room details.", "error");
    else alert("Please fill in all room details.");
    return;
  }

  try {
    await fetch(`${API_URL}/rooms`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeader() },
      body: JSON.stringify({
        id: roomNumber,
        type: roomType,
        price: roomRate, // Use 'price' to match backend expectation
        status: "available",
        guest: "",
      }),
    });
    form.reset(); // Clear form fields
    closeModal("addRoomModal");
    loadRooms();
  } catch (err) {
    if (window.UI && UI.toast)
      UI.toast("Add room error: " + err.message, "error");
    else alert("Add room error: " + err.message);
  }
}

async function deleteRoom(id) {
  if (!confirm("Delete room?")) return;
  try {
    await fetch(`${API_URL}/rooms/${id}`, {
      method: "DELETE",
      headers: authHeader(),
    });
    loadRooms();
  } catch (err) {
    if (window.UI && UI.toast)
      UI.toast("Delete room error: " + err.message, "error");
    else alert("Delete room error: " + err.message);
  }
}

// --------- BOOKINGS
async function loadBookings() {
  try {
    const res = await fetch(`${API_URL}/bookings`, fetchOptions("GET"));
    const bookings = await res.json();
    const container = document.getElementById("bookingsList"); // Assuming there's a bookingsList in admin.html
    if (!Array.isArray(bookings)) {
      container.innerHTML = '<p class="muted">No booking data.</p>';
      return;
    }
    container.innerHTML = bookings
      .map(
        (b) => `
      <div class="booking-row">
        <div>
          <strong>${escapeHtml(b.name || b.customer || "Guest")}</strong>
          <div class="muted">${escapeHtml(
            b.roomType || b.room_name || b.room || ""
          )} — ${escapeHtml(b.date || b.checkin || "")}</div>
        </div>
        <div>
          <button class="small-btn" onclick="cancelBooking(${
            b.id
          })">Cancel</button>
        </div>
      </div>
    `
      )
      .join("");
  } catch (err) {
    // Ensure the bookingsList element exists before trying to set innerHTML
    const bookingsListElement = document.getElementById("bookingsList");
    if (bookingsListElement) {
      bookingsListElement.innerHTML = `<p class="muted">Error: ${err.message}</p>`;
    } else {
      console.error(
        "Error loading bookings: bookingsList element not found.",
        err
      );
    }
  }
}

async function cancelBooking(id) {
  if (!confirm("Cancel this booking?")) return;
  try {
    await fetch(`${API_URL}/bookings/${id}`, {
      method: "DELETE",
      headers: authHeader(),
    });
    loadBookings();
  } catch (err) {
    if (window.UI && UI.toast)
      UI.toast("Cancel booking error: " + err.message, "error");
    else alert("Cancel booking error: " + err.message);
  }
}

// --------- Helpers
function authHeader() {
  if (USE_BACKEND_AUTH && jwtToken)
    return { Authorization: "Bearer " + jwtToken };
  return {};
}
function fetchOptions(method = "GET") {
  return {
    method,
    headers: { "Content-Type": "application/json", ...authHeader() },
  };
}
function escapeHtml(s) {
  if (!s) return "";
  let result = String(s);
  result = result.replace(/&/g, "&amp;");
  result = result.replace(/</g, "&lt;");
  result = result.replace(/>/g, "&gt;");
  result = result.replace(/"/g, "&quot;");
  result = result.replace(/'/g, "&#39;");
  return result;
}

// allow calling deleteRoom/cancelBooking from inline handlers
window.deleteRoom = deleteRoom;
window.cancelBooking = cancelBooking;
window.showSection = showSection; // Expose to global scope for inline onclick
window.openModal = openModal; // Expose to global scope for inline onclick
window.closeModal = closeModal; // Expose to global scope for inline onclick
window.viewRoomDetails = viewRoomDetails;
window.changeRoomStatus = changeRoomStatus;
window.bookRoom = bookRoom;
window.reportMaintenance = reportMaintenance;
window.addGuest = addGuest;
window.processCheckIn = processCheckIn;
window.processCheckOut = processCheckOut;
window.loadGuests = loadGuests;
window.loadRooms = loadRooms;
window.loadBookings = loadBookings;
window.loadPayments = loadPayments;
window.recordPayment = recordPayment;
window.generateInvoice = generateInvoice;
window.viewReceipt = viewReceipt;
window.refundPayment = refundPayment;
window.confirmPayment = confirmPayment;
window.followUpPayment = followUpPayment;
window.loadMenuItems = loadMenuItems;
window.addMenuItem = addMenuItem;
window.editMenuItem = editMenuItem;
window.loadRoomServiceOrders = loadRoomServiceOrders;
window.updateOrderStatus = updateOrderStatus;
window.addExtraService = addExtraService;
window.loadStaff = loadStaff;
window.addStaffMember = addStaffMember;
window.viewStaffProfile = viewStaffProfile;
window.editStaff = editStaff;
window.assignTask = assignTask;

// Initialize on load
document.addEventListener("DOMContentLoaded", function () {
  // Initially show login section and hide dashboard
  if (loginSection) loginSection.classList.remove("hidden");
  if (adminDashboardContent) adminDashboardContent.classList.add("hidden");

  // Pre-fill login fields for convenience during development
  const usernameInput = document.getElementById("username");
  const passwordInput = document.getElementById("password");
  if (usernameInput) usernameInput.value = "admin";
  if (passwordInput) passwordInput.value = "1234";

  // If not using backend auth, automatically show dashboard for development convenience
  if (!USE_BACKEND_AUTH) {
    showDashboard();
  }

  // Attach event listeners for new forms
  const bookRoomForm = document.getElementById("bookRoomForm");
  if (bookRoomForm) {
    bookRoomForm.addEventListener("submit", handleBookRoom);
  }

  const reportMaintenanceForm = document.getElementById(
    "reportMaintenanceForm"
  );
  if (reportMaintenanceForm) {
    reportMaintenanceForm.addEventListener("submit", handleReportMaintenance);
  }

  const addGuestForm = document.getElementById("addGuestForm");
  if (addGuestForm) {
    addGuestForm.addEventListener("submit", addGuest);
  }

  const checkInForm = document.getElementById("checkInModal");
  if (checkInForm) {
    checkInForm.addEventListener("submit", processCheckIn);
  }

  const checkOutForm = document.getElementById("checkOutModal");
  if (checkOutForm) {
    checkOutForm.addEventListener("submit", processCheckOut);
  }
  const recordPaymentForm = document.getElementById("recordPaymentForm");
  if (recordPaymentForm) {
    recordPaymentForm.addEventListener("submit", recordPayment);
  }

  const addMenuItemForm = document.getElementById("addMenuItemForm");
  if (addMenuItemForm) {
    addMenuItemForm.addEventListener("submit", addMenuItem);
  }

  const addOrderForm = document.getElementById("addOrderForm");
  if (addOrderForm) {
    addOrderForm.addEventListener("submit", handleAddOrder);
  }

  const addStaffForm = document.getElementById("addStaffForm");
  if (addStaffForm) {
    addStaffForm.addEventListener("submit", addStaffMember);
  }
});

// --------- ROOM MANAGEMENT FUNCTIONS
async function viewRoomDetails(roomNumber) {
  try {
    const res = await fetch(
      `${API_URL}/rooms/${roomNumber}`,
      fetchOptions("GET")
    );
    const room = await res.json();
    const roomDetailsContent = document.getElementById("roomDetailsContent");
    if (roomDetailsContent) {
      roomDetailsContent.innerHTML = `
        <p><strong>Room Number:</strong> ${escapeHtml(room.id)}</p>
        <p><strong>Room Type:</strong> ${escapeHtml(room.type)}</p>
        <p><strong>Rate:</strong> ₦${(
          room.rate || 0
        ).toLocaleString()}/night</p>
        <p><strong>Status:</strong> ${escapeHtml(room.status)}</p>
        <p><strong>Current Guest:</strong> ${escapeHtml(
          room.guest || "N/A"
        )}</p>
      `;
      openModal("viewRoomDetailsModal");
    }
  } catch (err) {
    if (window.UI && UI.toast)
      UI.toast("Error loading room details: " + err.message, "error");
    else alert("Error loading room details: " + err.message);
  }
}

async function changeRoomStatus(roomNumber) {
  const newStatus = prompt(
    `Enter new status for Room ${roomNumber} (e.g., available, occupied, cleaning, maintenance):`
  );
  if (newStatus) {
    try {
      await fetch(`${API_URL}/rooms/${roomNumber}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", ...authHeader() },
        body: JSON.stringify({ status: newStatus.toLowerCase() }),
      });
      loadRooms();
      if (window.UI && UI.toast)
        UI.toast(`Room ${roomNumber} status updated.`, "success");
      else alert(`Room ${roomNumber} status updated to ${newStatus}.`);
    } catch (err) {
      if (window.UI && UI.toast)
        UI.toast("Error changing room status: " + err.message, "error");
      else alert("Error changing room status: " + err.message);
    }
  }
}

function bookRoom(roomNumber) {
  const bookRoomNumberInput = document.getElementById("bookRoomNumber");
  if (bookRoomNumberInput) {
    bookRoomNumberInput.value = roomNumber;
  }
  openModal("bookRoomModal");
}

async function handleBookRoom(event) {
  event.preventDefault();
  const form = event.target;
  const roomNumber = form
    .querySelector('input[name="roomNumber"]')
    .value.trim();
  const guestName = form.querySelector('input[name="guestName"]').value.trim();
  const checkInDate = form.querySelector('input[name="checkInDate"]').value;
  const checkOutDate = form.querySelector('input[name="checkOutDate"]').value;

  if (!roomNumber || !guestName || !checkInDate || !checkOutDate) {
    if (window.UI && UI.toast)
      UI.toast("Please fill in all booking details.", "error");
    else alert("Please fill in all booking details.");
    return;
  }

  try {
    await fetch(`${API_URL}/bookings`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeader() },
      body: JSON.stringify({
        room_id: roomNumber,
        customer: guestName,
        checkin: checkInDate,
        checkout: checkOutDate,
        status: "confirmed",
      }),
    });
    form.reset();
    closeModal("bookRoomModal");
    loadBookings();
    loadRooms(); // Update room status on dashboard
    if (window.UI && UI.toast)
      UI.toast(`Room ${roomNumber} booked for ${guestName}.`, "success");
    else alert(`Room ${roomNumber} booked for ${guestName}.`);
  } catch (err) {
    if (window.UI && UI.toast)
      UI.toast("Error booking room: " + err.message, "error");
    else alert("Error booking room: " + err.message);
  }
}

function reportMaintenance(roomNumber) {
  const maintenanceRoomNumberInput = document.getElementById(
    "maintenanceRoomNumber"
  );
  if (maintenanceRoomNumberInput) {
    maintenanceRoomNumberInput.value = roomNumber;
  }
  openModal("reportMaintenanceModal");
}

async function handleReportMaintenance(event) {
  event.preventDefault();
  const form = event.target;
  const roomNumber = form
    .querySelector('input[name="roomNumber"]')
    .value.trim();
  const issueDescription = form
    .querySelector('textarea[name="issueDescription"]')
    .value.trim();

  if (!roomNumber || !issueDescription) {
    if (window.UI && UI.toast)
      UI.toast("Please fill in all maintenance details.", "error");
    else alert("Please fill in all maintenance details.");
    return;
  }

  try {
    // Assuming a backend endpoint for maintenance reports
    await fetch(`${API_URL}/maintenance`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeader() },
      body: JSON.stringify({
        room_id: roomNumber,
        issue: issueDescription,
        status: "pending",
      }),
    });
    form.reset();
    closeModal("reportMaintenanceModal");
    loadRooms(); // Update room status on dashboard if it changes to maintenance
    if (window.UI && UI.toast)
      UI.toast(`Maintenance issue for Room ${roomNumber} reported.`, "success");
    else
      alert(
        `Maintenance issue for Room ${roomNumber} reported: ${issueDescription}.`
      );
  } catch (err) {
    if (window.UI && UI.toast)
      UI.toast("Error reporting maintenance: " + err.message, "error");
    else alert("Error reporting maintenance: " + err.message);
  }
}

// --------- HOUSEKEEPING FUNCTIONS
async function loadHousekeepingTasks() {
  try {
    const res = await fetch(`${API_URL}/housekeeping`, fetchOptions("GET"));
    const tasks = await res.json();
    const cleaningStatusContainer = document.querySelector(
      "#housekeeping .grid > div:nth-child(1) .space-y-3"
    );
    const maintenanceIssuesContainer = document.querySelector(
      "#housekeeping .grid > div:nth-child(2) .space-y-3"
    );
    const staffTasksContainer = document.querySelector(
      "#housekeeping table tbody"
    );

    if (!Array.isArray(tasks)) {
      if (cleaningStatusContainer)
        cleaningStatusContainer.innerHTML =
          '<p class="muted">No cleaning tasks.</p>';
      if (maintenanceIssuesContainer)
        maintenanceIssuesContainer.innerHTML =
          '<p class="muted">No maintenance issues.</p>';
      if (staffTasksContainer)
        staffTasksContainer.innerHTML = '<p class="muted">No staff tasks.</p>';
      return;
    }

    // Clear existing content
    if (cleaningStatusContainer) cleaningStatusContainer.innerHTML = "";
    if (maintenanceIssuesContainer) maintenanceIssuesContainer.innerHTML = "";
    if (staffTasksContainer) staffTasksContainer.innerHTML = "";

    tasks.forEach((task) => {
      if (task.type === "cleaning") {
        if (cleaningStatusContainer) {
          cleaningStatusContainer.innerHTML += `
            <div class="flex justify-between items-center p-3 bg-${
              task.status === "clean"
                ? "green"
                : task.status === "in progress"
                ? "yellow"
                : "red"
            }-100 rounded">
              <span>Room ${escapeHtml(task.room_id)} - ${escapeHtml(
            task.status
          )}</span>
              ${
                task.status !== "clean"
                  ? `<button onclick="markCleaned(${task.room_id})" class="bg-gold hover:bg-gold-dark text-brown px-3 py-1 rounded text-sm">Mark Clean</button>`
                  : ""
              }
            </div>
          `;
        }
      } else if (task.type === "maintenance") {
        if (maintenanceIssuesContainer) {
          maintenanceIssuesContainer.innerHTML += `
            <div class="flex justify-between items-center p-3 bg-${
              task.status === "pending" ? "red" : "yellow"
            }-100 rounded">
              <div>
                <p class="font-semibold">Room ${escapeHtml(
                  task.room_id
                )} - ${escapeHtml(task.issue)}</p>
                <p class="text-sm text-gray-600">Status: ${escapeHtml(
                  task.status
                )}</p>
              </div>
              <button onclick="updateMaintenance(${
                task.id
              })" class="bg-brown hover:bg-brown-dark text-white px-3 py-1 rounded text-sm">Update</button>
            </div>
          `;
        }
      } else if (task.type === "staff") {
        if (staffTasksContainer) {
          staffTasksContainer.innerHTML += `
            <tr class="border-b">
              <td class="p-3">${escapeHtml(task.staff_member)}</td>
              <td class="p-3">${escapeHtml(task.task_description)}</td>
              <td class="p-3">${escapeHtml(task.room_id || "N/A")}</td>
              <td class="p-3">
                <span class="bg-${
                  task.status === "completed"
                    ? "green"
                    : task.status === "in progress"
                    ? "yellow"
                    : "red"
                }-500 text-white px-2 py-1 rounded text-sm">${escapeHtml(
            task.status
          )}</span>
              </td>
              <td class="p-3">
                <button onclick="updateTaskStatus(${
                  task.id
                })" class="bg-gold hover:bg-gold-dark text-brown px-3 py-1 rounded text-sm">Update</button>
              </td>
            </tr>
          `;
        }
      }
    });
  } catch (err) {
    console.error("Error loading housekeeping tasks: " + err.message);
  }
}

async function markCleaned(roomNumber) {
  if (!confirm(`Mark Room ${roomNumber} as clean?`)) return;
  try {
    await fetch(`${API_URL}/housekeeping/cleaning/${roomNumber}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json", ...authHeader() },
      body: JSON.stringify({ status: "clean" }),
    });
    loadHousekeepingTasks();
    loadRooms(); // Update room status on dashboard
    if (window.UI && UI.toast)
      UI.toast(`Room ${roomNumber} marked as clean.`, "success");
    else alert(`Room ${roomNumber} marked as clean.`);
  } catch (err) {
    if (window.UI && UI.toast)
      UI.toast("Error marking room clean: " + err.message, "error");
    else alert("Error marking room clean: " + err.message);
  }
}

async function assignCleaning(roomNumber) {
  const staffMember = prompt(`Assign cleaning for Room ${roomNumber} to:`);
  if (staffMember) {
    try {
      await fetch(`${API_URL}/housekeeping/cleaning`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeader() },
        body: JSON.stringify({
          room_id: roomNumber,
          staff_member: staffMember,
          status: "in progress",
          type: "cleaning",
        }),
      });
      loadHousekeepingTasks();
      loadRooms(); // Update room status on dashboard
      if (window.UI && UI.toast)
        UI.toast(`Cleaning for Room ${roomNumber} assigned.`, "success");
      else alert(`Cleaning for Room ${roomNumber} assigned to ${staffMember}.`);
    } catch (err) {
      if (window.UI && UI.toast)
        UI.toast("Error assigning cleaning: " + err.message, "error");
      else alert("Error assigning cleaning: " + err.message);
    }
  }
}

async function updateMaintenance(taskId) {
  const newStatus = prompt(
    `Enter new status for maintenance task ${taskId} (e.g., pending, in progress, completed):`
  );
  if (newStatus) {
    try {
      await fetch(`${API_URL}/housekeeping/maintenance/${taskId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", ...authHeader() },
        body: JSON.stringify({ status: newStatus.toLowerCase() }),
      });
      loadHousekeepingTasks();
      loadRooms(); // Update room status on dashboard
      if (window.UI && UI.toast)
        UI.toast(`Maintenance task updated.`, "success");
      else alert(`Maintenance task ${taskId} status updated to ${newStatus}.`);
    } catch (err) {
      if (window.UI && UI.toast)
        UI.toast("Error updating maintenance status: " + err.message, "error");
      else alert("Error updating maintenance status: " + err.message);
    }
  }
}

async function reportIssue() {
  openModal("reportMaintenanceModal"); // Re-use existing report maintenance modal
}

async function updateTaskStatus(taskId) {
  const newStatus = prompt(
    `Enter new status for staff task ${taskId} (e.g., pending, in progress, completed):`
  );
  if (newStatus) {
    try {
      await fetch(`${API_URL}/housekeeping/staff-task/${taskId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", ...authHeader() },
        body: JSON.stringify({ status: newStatus.toLowerCase() }),
      });
      loadHousekeepingTasks();
      if (window.UI && UI.toast) UI.toast(`Staff task updated.`, "success");
      else alert(`Staff task ${taskId} status updated to ${newStatus}.`);
    } catch (err) {
      if (window.UI && UI.toast)
        UI.toast("Error updating staff task status: " + err.message, "error");
      else alert("Error updating staff task status: " + err.message);
    }
  }
}

// --------- PAYMENTS FUNCTIONS
async function loadPayments() {
  try {
    const res = await fetch(`${API_URL}/payments`, fetchOptions("GET"));
    const payments = await res.json();
    const recentTransactionsContainer = document.querySelector(
      "#payments table tbody"
    );

    if (!Array.isArray(payments)) {
      if (recentTransactionsContainer)
        recentTransactionsContainer.innerHTML =
          '<p class="muted">No payment data.</p>';
      return;
    }

    if (recentTransactionsContainer) {
      recentTransactionsContainer.innerHTML = payments
        .map(
          (payment) => `
        <tr class="border-b hover:bg-gray-50">
          <td class="p-4">${escapeHtml(payment.transaction_id)}</td>
          <td class="p-4">${escapeHtml(payment.guest_name)}</td>
          <td class="p-4">₦${(payment.amount || 0).toLocaleString()}</td>
          <td class="p-4">${escapeHtml(payment.method)}</td>
          <td class="p-4">
            <span class="bg-${
              payment.status === "completed"
                ? "green"
                : payment.status === "pending"
                ? "yellow"
                : "red"
            }-500 text-white px-2 py-1 rounded text-sm">${escapeHtml(
            payment.status
          )}</span>
          </td>
          <td class="p-4">
            <button onclick="viewReceipt('${
              payment.transaction_id
            }')" class="bg-gold hover:bg-gold-dark text-brown px-3 py-1 rounded text-sm mr-2">Receipt</button>
            ${
              payment.status === "completed"
                ? `<button onclick="refundPayment('${payment.transaction_id}')" class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-sm">Refund</button>`
                : ""
            }
            ${
              payment.status === "pending"
                ? `<button onclick="confirmPayment('${payment.transaction_id}')" class="bg-brown hover:bg-brown-dark text-white px-3 py-1 rounded text-sm mr-2">Confirm</button>`
                : ""
            }
            ${
              payment.status === "pending"
                ? `<button onclick="followUpPayment('${payment.transaction_id}')" class="bg-gold hover:bg-gold-dark text-brown px-3 py-1 rounded text-sm">Follow Up</button>`
                : ""
            }
          </td>
        </tr>
      `
        )
        .join("");
    }
  } catch (err) {
    console.error("Error loading payments: " + err.message);
  }
}

async function recordPayment(event) {
  event.preventDefault();
  const form = event.target;
  const transactionId = form
    .querySelector('input[name="transactionId"]')
    .value.trim();
  const guestName = form.querySelector('input[name="guestName"]').value.trim();
  const amount = Number(form.querySelector('input[name="amount"]').value);
  const method = form.querySelector('select[name="method"]').value;

  if (!transactionId || !guestName || !amount || !method) {
    if (window.UI && UI.toast)
      UI.toast("Please fill in all payment details.", "error");
    else alert("Please fill in all payment details.");
    return;
  }

  try {
    await fetch(`${API_URL}/payments`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeader() },
      body: JSON.stringify({
        transaction_id: transactionId,
        guest_name: guestName,
        amount: amount,
        method: method,
        status: "completed", // Assuming immediate completion for new records
      }),
    });
    form.reset();
    closeModal("recordPaymentModal");
    loadPayments();
    if (window.UI && UI.toast)
      UI.toast(`Payment ${transactionId} recorded.`, "success");
    else alert(`Payment ${transactionId} recorded.`);
  } catch (err) {
    if (window.UI && UI.toast)
      UI.toast("Error recording payment: " + err.message, "error");
    else alert("Error recording payment: " + err.message);
  }
}

async function generateInvoice() {
  if (window.UI && UI.toast)
    UI.toast("Generate Invoice not yet implemented.", "info");
  else alert("Generate Invoice functionality (Not yet implemented)");
  // Implement logic to generate and display/download invoice
}

async function viewReceipt(transactionId) {
  if (window.UI && UI.toast)
    UI.toast(`View receipt ${transactionId} not yet implemented.`, "info");
  else
    alert(
      `View receipt for transaction ID: ${transactionId} (Not yet implemented)`
    );
  // Implement logic to fetch and display receipt
}

async function refundPayment(transactionId) {
  if (!confirm(`Refund payment ${transactionId}?`)) return;
  try {
    await fetch(`${API_URL}/payments/${transactionId}/refund`, {
      method: "POST",
      headers: authHeader(),
    });
    loadPayments();
    if (window.UI && UI.toast)
      UI.toast(`Payment ${transactionId} refunded.`, "success");
    else alert(`Payment ${transactionId} refunded.`);
  } catch (err) {
    if (window.UI && UI.toast)
      UI.toast("Error refunding payment: " + err.message, "error");
    else alert("Error refunding payment: " + err.message);
  }
}

async function confirmPayment(transactionId) {
  if (!confirm(`Confirm payment ${transactionId}?`)) return;
  try {
    await fetch(`${API_URL}/payments/${transactionId}/confirm`, {
      method: "POST",
      headers: authHeader(),
    });
    loadPayments();
    if (window.UI && UI.toast)
      UI.toast(`Payment ${transactionId} confirmed.`, "success");
    else alert(`Payment ${transactionId} confirmed.`);
  } catch (err) {
    if (window.UI && UI.toast)
      UI.toast("Error confirming payment: " + err.message, "error");
    else alert("Error confirming payment: " + err.message);
  }
}

async function followUpPayment(transactionId) {
  if (window.UI && UI.toast)
    UI.toast(`Follow up ${transactionId} not yet implemented.`, "info");
  else alert(`Follow up on payment ${transactionId} (Not yet implemented)`);
  // Implement logic to send a reminder or log a follow-up
}

// --------- FOOD & BEVERAGE FUNCTIONS
async function loadMenuItems() {
  try {
    const res = await fetch(`${API_URL}/menu`, fetchOptions("GET"));
    const menuItems = await res.json();
    const menuItemsContainer = document.querySelector(
      "#food .grid > div:nth-child(1) .space-y-3"
    );

    if (!Array.isArray(menuItems)) {
      if (menuItemsContainer)
        menuItemsContainer.innerHTML = '<p class="muted">No menu items.</p>';
      return;
    }

    if (menuItemsContainer) {
      menuItemsContainer.innerHTML = menuItems
        .map(
          (item) => `
        <div class="flex justify-between items-center p-3 border rounded">
          <div>
            <p class="font-semibold">${escapeHtml(item.name)}</p>
            <p class="text-sm text-gray-600">₦${(
              item.price || 0
            ).toLocaleString()}</p>
          </div>
          <button onclick="editMenuItem('${
            item.id
          }')" class="bg-gold hover:bg-gold-dark text-brown px-3 py-1 rounded text-sm">Edit</button>
        </div>
      `
        )
        .join("");
    }
  } catch (err) {
    console.error("Error loading menu items: " + err.message);
  }
}

async function addMenuItem(event) {
  event.preventDefault();
  const form = event.target;
  const itemName = form.querySelector('input[name="itemName"]').value.trim();
  const itemPrice = Number(form.querySelector('input[name="itemPrice"]').value);

  if (!itemName || !itemPrice) {
    alert("Please fill in all menu item details.");
    return;
  }

  try {
    await fetch(`${API_URL}/menu`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeader() },
      body: JSON.stringify({
        name: itemName,
        price: itemPrice,
      }),
    });
    form.reset();
    closeModal("addMenuItemModal");
    loadMenuItems();
    alert(`Menu item ${itemName} added.`);
  } catch (err) {
    alert("Error adding menu item: " + err.message);
  }
}

async function handleAddOrder(event) {
  event.preventDefault();
  const form = event.target;
  const roomNumber = form
    .querySelector('input[name="orderRoomNumber"]')
    .value.trim();
  const guestName = form
    .querySelector('input[name="orderGuestName"]')
    .value.trim();
  const items = form.querySelector('textarea[name="orderItems"]').value.trim();
  const totalPrice = Number(
    form.querySelector('input[name="orderTotalPrice"]').value
  );

  if (!roomNumber || !guestName || !items || !totalPrice) {
    if (window.UI && UI.toast)
      UI.toast("Please fill in all order details.", "error");
    else alert("Please fill in all order details.");
    return;
  }

  try {
    await fetch(`${API_URL}/room-service-orders`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeader() },
      body: JSON.stringify({
        room_id: roomNumber,
        guest_name: guestName,
        items: items,
        total_price: totalPrice,
        status: "preparing",
      }),
    });
    form.reset();
    closeModal("addOrderModal");
    loadRoomServiceOrders();
    if (window.UI && UI.toast)
      UI.toast(`Order for Room ${roomNumber} created.`, "success");
    else alert(`Order for Room ${roomNumber} created.`);
  } catch (err) {
    if (window.UI && UI.toast)
      UI.toast("Error creating order: " + err.message, "error");
    else alert("Error creating order: " + err.message);
  }
}

async function editMenuItem(itemId) {
  if (window.UI && UI.toast)
    UI.toast(`Edit menu item ${itemId} not yet implemented.`, "info");
  else
    alert(
      `Edit menu item functionality for item ID: ${itemId} (Not yet implemented)`
    );
  // Implement modal or form to edit menu item details
}

async function loadRoomServiceOrders() {
  try {
    const res = await fetch(
      `${API_URL}/room-service-orders`,
      fetchOptions("GET")
    );
    const orders = await res.json();
    const roomServiceOrdersContainer = document.querySelector(
      "#food .grid > div:nth-child(2) .space-y-3"
    );

    if (!Array.isArray(orders)) {
      if (roomServiceOrdersContainer)
        roomServiceOrdersContainer.innerHTML =
          '<p class="muted">No room service orders.</p>';
      return;
    }

    if (roomServiceOrdersContainer) {
      roomServiceOrdersContainer.innerHTML = orders
        .map(
          (order) => `
        <div class="p-3 border-l-4 border-${
          order.status === "delivered" ? "green" : "yellow"
        }-500 bg-${
            order.status === "delivered" ? "green" : "yellow"
          }-50 rounded">
          <div class="flex justify-between items-start">
            <div>
              <p class="font-semibold">Room ${escapeHtml(
                order.room_id
              )} - ${escapeHtml(order.guest_name)}</p>
              <p class="text-sm text-gray-600">${escapeHtml(order.items)}</p>
              <p class="text-sm text-brown font-semibold">₦${(
                order.total_price || 0
              ).toLocaleString()}</p>
            </div>
            <span class="bg-${
              order.status === "delivered" ? "green" : "yellow"
            }-500 text-white px-2 py-1 rounded text-sm">${escapeHtml(
            order.status
          )}</span>
          </div>
          ${
            order.status !== "delivered"
              ? `<button onclick="updateOrderStatus('${order.id}')" class="mt-2 bg-gold hover:bg-gold-dark text-brown px-3 py-1 rounded text-sm">Update Status</button>`
              : ""
          }
        </div>
      `
        )
        .join("");
    }
  } catch (err) {
    console.error("Error loading room service orders: " + err.message);
  }
}

async function updateOrderStatus(orderId) {
  const newStatus = prompt(
    `Enter new status for order ${orderId} (e.g., preparing, delivered):`
  );
  if (newStatus) {
    try {
      await fetch(`${API_URL}/room-service-orders/${orderId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", ...authHeader() },
        body: JSON.stringify({ status: newStatus.toLowerCase() }),
      });
      loadRoomServiceOrders();
      if (window.UI && UI.toast)
        UI.toast(`Order ${orderId} status updated.`, "success");
      else alert(`Order ${orderId} status updated to ${newStatus}.`);
    } catch (err) {
      if (window.UI && UI.toast)
        UI.toast("Error updating order status: " + err.message, "error");
      else alert("Error updating order status: " + err.message);
    }
  }
}

async function addExtraService(serviceType) {
  const roomNumber = prompt(`Enter room number for ${serviceType} service:`);
  const guestName = prompt(`Enter guest name for ${serviceType} service:`);
  const price = prompt(`Enter price for ${serviceType} service:`);

  if (!roomNumber || !guestName || !price) {
    if (window.UI && UI.toast)
      UI.toast("Please fill in all service details.", "error");
    else alert("Please fill in all service details.");
    return;
  }

  try {
    await fetch(`${API_URL}/extra-services`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeader() },
      body: JSON.stringify({
        room_id: roomNumber,
        guest_name: guestName,
        service_type: serviceType,
        price: Number(price),
        status: "billed",
      }),
    });
    if (window.UI && UI.toast)
      UI.toast(`${serviceType} added to Room ${roomNumber}'s bill.`, "success");
    else alert(`${serviceType} service added to Room ${roomNumber}'s bill.`);
  } catch (err) {
    if (window.UI && UI.toast)
      UI.toast("Error adding extra service: " + err.message, "error");
    else alert("Error adding extra service: " + err.message);
  }
}

// --------- STAFF MANAGEMENT FUNCTIONS
async function loadStaff() {
  try {
    const res = await fetch(`${API_URL}/staff`, fetchOptions("GET"));
    const staff = await res.json();
    const staffDirectoryContainer =
      document.querySelector("#staff table tbody");

    if (!Array.isArray(staff)) {
      if (staffDirectoryContainer)
        staffDirectoryContainer.innerHTML =
          '<p class="muted">No staff data.</p>';
      return;
    }

    if (staffDirectoryContainer) {
      staffDirectoryContainer.innerHTML = staff
        .map(
          (member) => `
        <tr class="border-b hover:bg-gray-50">
          <td class="p-4">
            <div>
              <p class="font-semibold">${escapeHtml(member.name)}</p>
              <p class="text-sm text-gray-600">${escapeHtml(member.email)}</p>
            </div>
          </td>
          <td class="p-4">${escapeHtml(member.role)}</td>
          <td class="p-4">${escapeHtml(member.department)}</td>
          <td class="p-4">
            <span class="bg-${
              member.status === "on duty" ? "green" : "gray"
            }-500 text-white px-2 py-1 rounded text-sm">${escapeHtml(
            member.status
          )}</span>
          </td>
          <td class="p-4">⭐⭐⭐⭐⭐</td> <!-- Placeholder for performance -->
          <td class="p-4">
            <button onclick="viewStaffProfile('${
              member.id
            }')" class="bg-gold hover:bg-gold-dark text-brown px-3 py-1 rounded text-sm mr-2">View</button>
            <button onclick="editStaff('${
              member.id
            }')" class="bg-brown hover:bg-brown-dark text-white px-3 py-1 rounded text-sm">Edit</button>
          </td>
        </tr>
      `
        )
        .join("");
    }
  } catch (err) {
    console.error("Error loading staff: " + err.message);
  }
}

async function addStaffMember(event) {
  event.preventDefault();
  const form = event.target;
  const fullName = form.querySelector('input[name="fullName"]').value.trim();
  const email = form.querySelector('input[name="email"]').value.trim();
  const role = form.querySelector('select[name="role"]').value;
  const department = form.querySelector('select[name="department"]').value;

  if (!fullName || !email || !role || !department) {
    if (window.UI && UI.toast)
      UI.toast("Please fill in all staff details.", "error");
    else alert("Please fill in all staff details.");
    return;
  }

  try {
    await fetch(`${API_URL}/staff`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeader() },
      body: JSON.stringify({
        name: fullName,
        email: email,
        role: role,
        department: department,
        status: "off duty", // Default status
      }),
    });
    form.reset();
    closeModal("addStaffModal");
    loadStaff();
    if (window.UI && UI.toast)
      UI.toast(`Staff member ${fullName} added.`, "success");
    else alert(`Staff member ${fullName} added.`);
  } catch (err) {
    if (window.UI && UI.toast)
      UI.toast("Error adding staff member: " + err.message, "error");
    else alert("Error adding staff member: " + err.message);
  }
}

async function viewStaffProfile(staffId) {
  alert(
    `View staff profile functionality for staff ID: ${staffId} (Not yet implemented)`
  );
  // Implement modal or page to display staff profile
}

async function editStaff(staffId) {
  alert(
    `Edit staff functionality for staff ID: ${staffId} (Not yet implemented)`
  );
  // Implement modal or form to edit staff details
}

async function assignTask(staffId) {
  alert(
    `Assign task functionality for staff ID: ${staffId} (Not yet implemented)`
  );
  // Implement modal or form to assign a task
}

// --------- GUEST MANAGEMENT FUNCTIONS
async function loadGuests() {
  try {
    const res = await fetch(`${API_URL}/guests`, fetchOptions("GET"));
    const guests = await res.json();
    const container = document.getElementById("bookingsList"); // Re-using bookingsList for now, will create a dedicated guest list later
    if (!Array.isArray(guests)) {
      container.innerHTML = '<p class="muted">No guest data.</p>';
      return;
    }
    container.innerHTML = `
      <table class="w-full text-left table-auto">
        <thead class="bg-gold-light">
          <tr>
            <th class="p-4">Name</th>
            <th class="p-4">Email</th>
            <th class="p-4">Phone</th>
            <th class="p-4">ID/Passport</th>
            <th class="p-4">Actions</th>
          </tr>
        </thead>
        <tbody>
          ${guests
            .map(
              (guest) => `
            <tr class="border-b hover:bg-gray-50">
              <td class="p-4">${escapeHtml(guest.name)}</td>
              <td class="p-4">${escapeHtml(guest.email)}</td>
              <td class="p-4">${escapeHtml(guest.phone)}</td>
              <td class="p-4">${escapeHtml(guest.idNumber)}</td>
              <td class="p-4">
                <button onclick="editGuest('${
                  guest.id
                }')" class="bg-gold hover:bg-gold-dark text-brown px-3 py-1 rounded text-sm mr-2">Edit</button>
                <button onclick="deleteGuest('${
                  guest.id
                }')" class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-sm">Delete</button>
              </td>
            </tr>
          `
            )
            .join("")}
        </tbody>
      </table>
    `;
  } catch (err) {
    const bookingsListElement = document.getElementById("bookingsList");
    if (bookingsListElement) {
      bookingsListElement.innerHTML = `<p class="muted">Error loading guests: ${err.message}</p>`;
    } else {
      console.error(
        "Error loading guests: bookingsList element not found.",
        err
      );
    }
  }
}

async function addGuest(event) {
  event.preventDefault();
  const form = event.target;
  const fullName = form.querySelector('input[type="text"]').value.trim();
  const email = form.querySelector('input[type="email"]').value.trim();
  const phone = form.querySelector('input[type="tel"]').value.trim();
  const idNumber = form
    .querySelector('input[type="text"]:nth-of-type(2)')
    .value.trim(); // Assuming second text input is ID/Passport

  if (!fullName || !email || !phone || !idNumber) {
    if (window.UI && UI.toast)
      UI.toast("Please fill in all guest details.", "error");
    else alert("Please fill in all guest details.");
    return;
  }

  try {
    await fetch(`${API_URL}/guests`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeader() },
      body: JSON.stringify({
        name: fullName,
        email: email,
        phone: phone,
        idNumber: idNumber,
      }),
    });
    form.reset();
    closeModal("addGuestModal");
    loadGuests();
    if (window.UI && UI.toast) UI.toast(`Guest ${fullName} added.`, "success");
    else alert(`Guest ${fullName} added.`);
  } catch (err) {
    if (window.UI && UI.toast)
      UI.toast("Error adding guest: " + err.message, "error");
    else alert("Error adding guest: " + err.message);
  }
}

async function processCheckIn(event) {
  event.preventDefault();
  const form = event.target;
  const guestName = form.querySelector("select:nth-of-type(1)").value;
  const roomNumber = form.querySelector("select:nth-of-type(2)").value;
  const checkOutDate = form.querySelector('input[type="date"]').value;

  if (
    guestName === "Select Guest" ||
    roomNumber === "Select Room" ||
    !checkOutDate
  ) {
    if (window.UI && UI.toast)
      UI.toast("Please select guest, room, and check-out date.", "error");
    else alert("Please select guest, room, and check-out date.");
    return;
  }

  try {
    // Assuming a backend endpoint for check-in
    await fetch(`${API_URL}/checkin`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeader() },
      body: JSON.stringify({
        guest_name: guestName,
        room_id: roomNumber,
        check_out_date: checkOutDate,
      }),
    });
    form.reset();
    closeModal("checkInModal");
    loadBookings(); // Update bookings list
    loadRooms(); // Update room status
    if (window.UI && UI.toast)
      UI.toast(`${guestName} checked into Room ${roomNumber}.`, "success");
    else alert(`${guestName} checked into Room ${roomNumber}.`);
  } catch (err) {
    if (window.UI && UI.toast)
      UI.toast("Error during check-in: " + err.message, "error");
    else alert("Error during check-in: " + err.message);
  }
}

async function processCheckOut(event) {
  event.preventDefault();
  const form = event.target;
  const guestName = form.querySelector("select:nth-of-type(1)").value; // Assuming a similar structure to check-in modal

  if (guestName === "Select Guest") {
    if (window.UI && UI.toast)
      UI.toast("Please select a guest to check out.", "error");
    else alert("Please select a guest to check out.");
    return;
  }

  try {
    // Assuming a backend endpoint for check-out
    await fetch(`${API_URL}/checkout`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeader() },
      body: JSON.stringify({
        guest_name: guestName,
      }),
    });
    form.reset();
    closeModal("checkOutModal");
    loadBookings(); // Update bookings list
    loadRooms(); // Update room status
    if (window.UI && UI.toast) UI.toast(`${guestName} checked out.`, "success");
    else alert(`${guestName} checked out.`);
  } catch (err) {
    if (window.UI && UI.toast)
      UI.toast("Error during check-out: " + err.message, "error");
    else alert("Error during check-out: " + err.message);
  }
}

async function editGuest(guestId) {
  if (window.UI && UI.toast)
    UI.toast(`Edit guest ${guestId} not yet implemented.`, "info");
  else
    alert(
      `Edit guest functionality for guest ID: ${guestId} (Not yet implemented)`
    );
  // Implement modal or form to edit guest details
}

async function deleteGuest(guestId) {
  if (!confirm("Delete guest?")) return;
  try {
    await fetch(`${API_URL}/guests/${guestId}`, {
      method: "DELETE",
      headers: authHeader(),
    });
    loadGuests();
    if (window.UI && UI.toast) UI.toast(`Guest ${guestId} deleted.`, "success");
    else alert(`Guest ${guestId} deleted.`);
  } catch (err) {
    if (window.UI && UI.toast)
      UI.toast("Delete guest error: " + err.message, "error");
    else alert("Delete guest error: " + err.message);
  }
}
